import { Session } from '@supabase/supabase-js';
import { Redirect, Stack, useSegments } from 'expo-router';
import React, { Component, ErrorInfo, ReactNode, createContext, useCallback, useContext, useEffect, useState, useRef } from 'react';
import { ActivityIndicator, Text, View, Platform, TouchableOpacity } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { supabase } from '../lib/supabase';

type Profile = {
  id: string;
  nama: string;
  tanggal_lahir: string;
  alamat: string | null;
  hobi: string | null;
  foto_url: string | null;
  pendidikan: string | null;
  pekerjaan: string | null;
  bio: string | null;
  negara: string | null;
  terms_accepted: boolean;
  location_asked: boolean;
  onboarding_complete: boolean;
  push_token: string | null;
  skill_level: string | null;
  life_tags: string[] | null;
  interests: string[] | null;
  workout_preference: string | null;
};

type AuthContextType = {
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  checkingProfile: boolean;
  refreshProfile: () => Promise<void>;
};

export const AuthContext = createContext<AuthContextType>({
  session: null,
  profile: null,
  loading: true,
  checkingProfile: false,
  refreshProfile: async () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

async function registerForPushNotificationsAsync() {
  console.log("Push notifications temporarily disabled for Expo Go compatibility on Android.");
  return null;
}

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class RootErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error caught by RootErrorBoundary:", error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  public render() {
    if (this.state.hasError) {
      return (
        <View style={{ flex: 1, backgroundColor: '#090A0D', justifyContent: 'center', alignItems: 'center', padding: 24 }}>
          <Text style={{ color: '#FF572F', fontSize: 24, fontWeight: 'bold', marginBottom: 12, textAlign: 'center' }}>Something went wrong</Text>
          <Text style={{ color: '#92959E', fontSize: 14, textAlign: 'center', marginBottom: 24 }}>
            {__DEV__ && this.state.error ? this.state.error.toString() : 'An unexpected error occurred in the application.'}
          </Text>
          <TouchableOpacity 
            style={{ backgroundColor: '#FF572F', paddingHorizontal: 24, paddingVertical: 14, borderRadius: 12 }}
            onPress={this.handleReset}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 }}>Try Again</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return this.props.children;
  }
}

export default function RootLayout() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [checkingProfile, setCheckingProfile] = useState(true);
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => { isMounted.current = false; };
  }, []);

  const segments = useSegments();

  useEffect(() => {
    supabase.auth.getSession()
      .then(({ data: { session } }) => { setSession(session); })
      .catch((err) => { console.error("Error fetching auth session:", err); })
      .finally(() => { setLoading(false); });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (!session) setProfile(null);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  const fetchProfile = useCallback(async () => {
    if (!session) return;
    setCheckingProfile(true);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*, terms_accepted, location_asked, onboarding_complete, push_token')
        .eq('id', session.user.id)
        .single();

      if (!error && data) {
        if (isMounted.current) {
          setProfile(data as Profile);
        }
        
        // Minta izin notifikasi & simpan token ke DB
        const token = await registerForPushNotificationsAsync();
        if (token && data.push_token !== token && isMounted.current) {
          await supabase.from('profiles').update({ push_token: token }).eq('id', session.user.id);
        }
      } else if (error) {
        console.error("Error fetching profile:", error);
      }
    } catch (e) {
      console.error("Unexpected error in fetchProfile:", e);
    } finally {
      if (isMounted.current) setCheckingProfile(false);
    }
  }, [session]);

  useEffect(() => { if (session) fetchProfile(); }, [session, fetchProfile]);

  // Instead of early return which unmounts Stack, we use an absolute overlay

  const inAuthGroup = segments[0] === 'login';
  const inOnboardingGroup = (segments[0] as string) === 'onboarding';

  let redirectTo: string | null = null;

  if (!session) {
    if (!inAuthGroup) redirectTo = '/login';
  } else if (profile) {
    if (!profile.terms_accepted || !profile.location_asked || !profile.onboarding_complete) {
      if (!inOnboardingGroup) {
        if (!profile.terms_accepted) redirectTo = '/onboarding/terms';
        else if (!profile.location_asked) redirectTo = '/onboarding/location';
        else if (!profile.onboarding_complete) redirectTo = '/onboarding/questionnaire';
      }
    } 
    else if (inAuthGroup || inOnboardingGroup) {
      redirectTo = '/';
    }
  } else {
    if (!checkingProfile && !inAuthGroup && !inOnboardingGroup) redirectTo = '/onboarding/terms';
  }

  return (
    <RootErrorBoundary>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <AuthContext.Provider value={{ session, profile, loading, checkingProfile, refreshProfile: fetchProfile }}>
          <Stack screenOptions={{ headerShown: false }} />
          {redirectTo && <Redirect href={redirectTo as any} />}
          
          {/* Loading Overlay to prevent unmounting the Stack context */}
          {(loading || (session && checkingProfile && !profile)) && (
            <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#0B0D12', justifyContent: 'center', alignItems: 'center', zIndex: 9999 }}>
              <ActivityIndicator size="large" color="#FF5A2A" />
            </View>
          )}
        </AuthContext.Provider>
      </GestureHandlerRootView>
    </RootErrorBoundary>
  );
}