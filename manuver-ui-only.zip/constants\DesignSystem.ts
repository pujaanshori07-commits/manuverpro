export const COLORS = {
  background: '#090A0D',
  surface: '#171A21',
  elevatedSurface: '#1D2028',
  primary: '#FF572F', // Orange action color
  text: '#FFFFFF',
  secondaryText: '#92959E',
  success: '#4CAF50', // Muted green for online status
  error: '#FF3B30', // Standard red for destructive actions
  border: '#232730', // Very subtle dark gray
};

export const SIZES = {
  borderRadius: 20, // 16-24px for major cards
  padding: 16,
};
